repo: xavierkain-apps/QuiX
branch: main

## Last sync
date: 2026-09-22T13:52:38Z

### Updated in this project
- Mock screenshots generated from App/TransferWindow.swift, App/MenuBarPopover.swift, App/Onboarding.swift into shots/.
- v2 hero rewritten around time saved (automatic import + automatic sorting).
- v2 landing page: shorter copy, visual-first, real app icon.
- Onboarding recap (3 screens) lifted from App/Onboarding.swift; traits copy verbatim.
- Real app icon PNGs copied from Support/AppIcon.iconset/.
- Palette from App/Theme.swift + tools/AppIcon.swift (ink #101017/#1A191D, GoPro blue #00A3E4, light #A9DCF5).

## Screen map
| Screen | Built from |
|---|---|
| QuiX Mockups.dc.html (screenshot source) | App/TransferWindow.swift, App/MenuBarPopover.swift, App/Onboarding.swift, App/Theme.swift |
| QuiX Landing v2.dc.html | App/Onboarding.swift, App/Theme.swift, tools/AppIcon.swift, Support/AppIcon.iconset/, README.md |
| QuiX Landing.dc.html (v1) | README.md, BRIEF.md, App/Theme.swift |

## Sync history
- 2026-09-22T13:44:55Z — v2 landing page, onboarding recap, icon assets copied.
- 2026-09-22T13:35:57Z — initial build of the landing page from README/BRIEF/Theme.swift.
